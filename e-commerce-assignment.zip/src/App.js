import './App.css';

import Ecommerce from './components/Ecommerce';

function App() {
  return (
    <div className="App">
      <Ecommerce />
    </div>
  );
}

export default App;
